package factory_method;

import vehicle_centers.LocationCenter;

import vehicle_components.VehicleSubType;

public interface IVehicleCenter {
    IVehicle CreateCar(LocationCenter center, VehicleSubType subType);

}
