package factory_method;

import vehicle_centers.LocationCenter;
import vehicle_components.VehicleSubType;
import vehicle_components.VehicleType;

import java.util.LinkedList;
import java.util.List;

public class JeepCenter implements IVehicleCenter {
    List<VehicleSubType> subTypes;

    public JeepCenter() {
        subTypes = new LinkedList<VehicleSubType>();
        subTypes.add(VehicleSubType.SPORTS);
        subTypes.add(VehicleSubType.NORMAL);
        subTypes.add(VehicleSubType.SUV);
    }

    public IVehicle CreateCar(LocationCenter center, VehicleSubType subType) {
        if (center.isContains(VehicleType.JEEP) && subTypes.contains(subType)) {
            System.out.println(subType + " Jeep was created at " + center.getClass().getName());
            return new Jeep(subType);
        } else {
            System.out.println("Cannot create vehicle.");
            return null;
        }
    }
}
