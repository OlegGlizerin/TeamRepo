package factory_method;

import vehicle_centers.PetahTikvaCenter;
import vehicle_components.VehicleSubType;

public class Main {
    public static void main(String [] args)
    {
        PetahTikvaCenter ptCenter = new PetahTikvaCenter(VehicleSubType.SPORTS);
        IVehicleCenter jeepCenter = new JeepCenter();
        Jeep jeep = (Jeep) jeepCenter.CreateCar(ptCenter, VehicleSubType.SPORTS);

    }

}
