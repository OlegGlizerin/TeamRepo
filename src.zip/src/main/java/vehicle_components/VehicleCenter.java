package vehicle_components;

public enum VehicleCenter {
    PETAH_TIKVA,
    HERZLIYA
}
