package vehicle_components;

public class TruckEngine extends Engine {

    protected void initVolume() {
        volume = 2400;
    }
}
