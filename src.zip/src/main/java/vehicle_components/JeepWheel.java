package vehicle_components;

public class JeepWheel extends Wheel {

    protected void initSize() {
        size = 12;
    }

}
