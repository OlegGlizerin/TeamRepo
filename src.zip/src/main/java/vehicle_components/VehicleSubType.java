package vehicle_components;

public enum VehicleSubType {
    SPORTS,
    SUV,
    HOVER,
    NORMAL
}
