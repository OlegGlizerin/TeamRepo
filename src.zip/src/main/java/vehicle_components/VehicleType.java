package vehicle_components;

public enum VehicleType {
    PRIVATE_CAR,
    MOTORBIKE,
    JEEP,
    TRUCK
}
