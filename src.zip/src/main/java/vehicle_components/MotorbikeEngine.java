package vehicle_components;

public class MotorbikeEngine extends Engine {

    protected void initVolume() {
        volume = 1000;
    }
}
