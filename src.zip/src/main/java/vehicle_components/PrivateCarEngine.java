package vehicle_components;

public class PrivateCarEngine extends Engine {


    protected void initVolume() {
        volume = 1500;
    }
}
