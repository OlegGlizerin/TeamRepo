package vehicle_components;

public class PrivateCarWheel extends Wheel {

    protected void initSize() {
        size = 10;
    }
}
