package vehicle_components;

public class TruckWheel extends Wheel {

    protected void initSize() {
        size = 20;
    }
}
