package vehicle_components;

public class MotorbikeWheel extends Wheel{

    protected void initSize() {
        size = 8;
    }
}
