package vehicle_components;

public class JeepEngine extends Engine {

    protected void initVolume() {
        volume = 2000;
    }
}
